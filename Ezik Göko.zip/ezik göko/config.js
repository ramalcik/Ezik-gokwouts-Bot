﻿const config = {
  "botStatus": ["Developed By Göko","Göko ❤"],
  "prefix": ["!", "."],
  "token": "",
  "mongoose": "",
  "botOwners": ["937434889614151720"],
  "guildID": "",
  
  "emojis": {
    "yes_name": "yes_gko",
    "no_name": "no_gko",
    "mute_name": "gko_mute"
  }
  }
  
  module.exports = config;
  